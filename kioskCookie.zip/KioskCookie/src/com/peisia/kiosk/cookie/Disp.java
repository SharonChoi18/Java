package com.peisia.kiosk.cookie;

import com.peisia.util.Cw;

public class Disp {
	String x = "x";
	final static String DOT = "🍪";
	final static int DOT_COUNT =30;
	public static void line() {
		for (int i = 0; i <DOT_COUNT; i=i+1) {
			Cw.w(DOT);	
		}
		Cw.wn();
	}
	public static void dot(int n) {
		for(int i=0;i<n;i++) {
			Cw.w(DOT);
		}
     }
	public static void title() {
		line();
		dot(12);
		Cw.w("바삭바삭쿠키샵");
		dot(13);
		Cw.wn();
		line();
	}
} 
