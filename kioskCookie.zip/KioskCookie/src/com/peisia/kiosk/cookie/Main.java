package com.peisia.kiosk.cookie;

public class Main {
	
	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();	
	}

}
