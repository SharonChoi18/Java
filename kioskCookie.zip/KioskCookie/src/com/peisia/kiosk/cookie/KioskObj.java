package com.peisia.kiosk.cookie;

import java.util.ArrayList;
import java.util.Scanner;

import com.peisia.kiosk.product.Cookie;
import com.peisia.kiosk.product.Drink;
import com.peisia.kiosk.product.Product;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>(); 
	public static ArrayList<Product> Products = new ArrayList<>(); 
	public static Scanner sc = new Scanner(System.in); 
	public static String cmd;

public static void productload() {
	Products.add(new Drink("아메리카노",2000));
	Products.add(new Drink("밀크티",3000));
	Products.add(new Cookie("아몬드쿠키",4000));
	Products.add(new Cookie("초코쿠키",4000));
	Products.add(new Cookie("치즈쿠키",3000));
	}
}