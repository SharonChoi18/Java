package com.peisia.kiosk.product;

public class Drink extends Product{

	public Drink(String xx, int yy) {
		super(xx, yy);
		
	}

}
