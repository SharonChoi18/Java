package com.peisia.kiosk.product;

public class Cookie extends Product {

	public Cookie(String xx, int yy) {
		super(xx, yy);
	}

}
